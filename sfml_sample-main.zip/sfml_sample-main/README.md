# sfml_sample  
Шаблон подключения библиотеки SFML для Visual Studio 2019  

